```mermaid
stateDiagram
specification --> (module)A
(module)A-->(struct)B
(struct)B-->(declaration)c
(declaration)c-->(type)int8
(declaration)c-->(value)8.6

```