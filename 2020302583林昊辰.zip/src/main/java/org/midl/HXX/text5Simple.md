```mermaid
stateDiagram
specification --> (module)m
(module)m-->(struct)s
(struct)s-->(declaration)A
(declaration)A-->(type)int8
(declaration)A-->(value)8

```